import React from "react";

const Loader = () => {
  return (
    <div>
      <h1>Loader</h1>
    </div>
  );
};

export default Loader;
