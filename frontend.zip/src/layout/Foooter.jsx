import React from "react";

const Foooter = () => {
  return <div></div>;
};

export default Foooter;
